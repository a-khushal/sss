// Solana-specific implementation for threshold wallet
import { Keypair } from "@solana/web3.js"
import bs58 from "bs58"
import secrets from "secrets.js-grempe"

export function generateSolanaWallet() {
  // Generate a proper Solana keypair
  const keypair = Keypair.generate()

  const privateKey = bs58.encode(keypair.secretKey)
  const publicKey = keypair.publicKey.toBase58()
  const address = keypair.publicKey.toBase58() // In Solana, address = public key

  return {
    privateKey,
    publicKey,
    address,
    keypair, // Include the actual keypair for signing
  }
}

export function deriveWalletFromPrivateKey(privateKey: string) {
  try {
    // Decode the base58 private key
    const secretKey = bs58.decode(privateKey)

    // Validate the key length
    if (secretKey.length !== 64) {
      throw new Error("Invalid Solana private key length - must be 64 bytes")
    }

    const keypair = Keypair.fromSecretKey(secretKey)

    const publicKey = keypair.publicKey.toBase58()
    const address = keypair.publicKey.toBase58()

    return {
      privateKey,
      publicKey,
      address,
      keypair,
    }
  } catch (error) {
    throw new Error(`Invalid Solana private key format: ${error.message}`)
  }
}

export function splitSecret(secretBase58: string, totalShares: number, threshold: number): string[] {
  // bs58 → bytes → hex
  const secretBytes = bs58.decode(secretBase58)
  const secretHex = Array.from(secretBytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("")

  // secrets.js returns pure-hex shares
  const rawShares = secrets.share(secretHex, totalShares, threshold)

  // Keep UI format "index-hex"
  return rawShares.map((hex, i) => `${i + 1}-${hex}`)
}

export function reconstructSecret(shares: string[]): string {
  if (shares.length < 2) throw new Error("At least 2 shares required")

  // Extract the HEX part (`index-hex`)
  const hexShares = shares.map((s, idx) => {
    const parts = s.trim().split("-")
    if (parts.length !== 2) {
      throw new Error(`Share ${idx + 1} wrong format. Expected "index-hex"`)
    }
    return parts[1]
  })

  // Combine back to hex secret
  let secretHex: string
  try {
    secretHex = secrets.combine(hexShares)
  } catch {
    throw new Error("Shares do not satisfy the threshold or are corrupted")
  }

  // hex → bytes → base58
  if (secretHex.length !== 128) throw new Error("Reconstructed key has invalid length")

  const bytes = new Uint8Array(secretHex.match(/.{2}/g)!.map((h) => Number.parseInt(h, 16)))
  return bs58.encode(bytes)
}

// Calculate modular inverse using extended Euclidean algorithm

// Greatest common divisor

// Legacy functions for backward compatibility
export function generateWallet() {
  return generateSolanaWallet()
}
